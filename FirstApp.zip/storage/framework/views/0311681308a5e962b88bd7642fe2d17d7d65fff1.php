<h4>Hi</h4>
<?php /**PATH D:\xampp-server\htdocs\FirstApp\resources\views/hello.blade.php ENDPATH**/ ?>