<?php $__env->startSection('content'); ?>
<H1>Services</H1>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp-server\htdocs\FirstApp\resources\views/new/services.blade.php ENDPATH**/ ?>