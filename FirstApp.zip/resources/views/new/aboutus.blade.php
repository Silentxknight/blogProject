@extends('layouts.app')
@section('content')
<H1>AboutUs</H1>
@endsection

